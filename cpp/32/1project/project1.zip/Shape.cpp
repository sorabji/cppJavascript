#include "Shape.h"
using namespace std;

Shape::Shape()
{
}
Shape::~Shape()
{
}
double Shape::calcArea()
{
}
